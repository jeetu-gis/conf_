# Safe to commit: these are REFERENCES, not values.
# Resolved only at process start by:  op run --env-file=.env.tpl -- npm start
# Create a vault named "demo" with an item "secrets-agent-demo" holding these fields first.
DATABASE_URL=op://demo/secrets-agent-demo/database_url
STRIPE_SECRET_KEY=op://demo/secrets-agent-demo/stripe_secret_key
OPENAI_API_KEY=op://demo/secrets-agent-demo/openai_api_key
